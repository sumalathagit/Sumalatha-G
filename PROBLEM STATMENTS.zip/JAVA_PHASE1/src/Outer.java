

class Outer {

	public class Inner{
		public void show() {
			System.out.println("From Inner class method");
		}
	}
}

  class Main{
	public static void main(String[] args) {
		Outer.Inner in=new Outer().new Inner();
		in.show();
		System.out.println("Hi");
	}
} 
