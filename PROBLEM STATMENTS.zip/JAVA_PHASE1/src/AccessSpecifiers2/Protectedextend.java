package AccessSpecifiers2;
import AccessSpecifiers.*;
public class Protectedextend extends ProtectedOne {

	public static void main(String[] args) {
		Protectedextend obj = new Protectedextend ();   
	       obj.display();  
	}

}

