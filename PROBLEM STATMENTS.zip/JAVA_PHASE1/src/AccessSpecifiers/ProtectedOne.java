package AccessSpecifiers;
 
 
 
 
public class ProtectedOne {

	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}



