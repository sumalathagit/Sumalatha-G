package AccessSpecifiers;

//Private Modifier

class PrivateAccess{
	private void display()
	{
		System.out.println("I am Private modifier");
	}
}
public class Private {
public static void main(String[] args) {
	System.out.println("Hi I am private");
	PrivateAccess obj = new PrivateAccess();
	 
}
	
}
