package AccessSpecifiers;

public class ModProtect {

	public void display() {
		// TODO Auto-generated method stub
		
	}

}
